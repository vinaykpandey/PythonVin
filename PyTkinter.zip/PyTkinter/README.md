tkinter, PyQt4, PyQt5, WxPython


pack
place
grid
