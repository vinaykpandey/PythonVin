from tkinter import *
root = Tk()
root.title("Set Size")
root.geometry("500x300")

root.mainloop()