from tkinter import *
root1 = Tk()
root2 = Tk()



root1.mainloop()