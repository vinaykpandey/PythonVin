from tkinter import *
root = Tk()
root.title("Welcome User")


root.mainloop()